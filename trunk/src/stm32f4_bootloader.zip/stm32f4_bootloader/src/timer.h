/*
 * timer.h
 *
 *  Created on: Dec 31, 2012
 *      Author: davhak
 */

#ifndef MISC_TIMER_H_
#define MISC_TIMER_H_

#include "defs.h"
#include "stm32f4xx_rcc.h"

//#define TIMER_1US_CLOCK		1000000 // 1 MHz
#define TIMER_TIM			   TIM2 //TIM4
#define RCC_1US_TIMER		RCC_APB1Periph_TIM2 //RCC_APB1Periph_TIM4

void TimerUS_Enable();
void TimerUS_Disable();
void TimerUS_StartDelayAndReturn(U32 delay);
void TimerUS_StartDelayAndWait(U32 delay);
U8 TimerUS_IsBusy();
U8 IsTimerUS_Enabled();

#endif /* MISC_TIMER_H_ */
