#include "defines.h"
#include "stm32f4xx.h"
//#include "tm_stm32f4_disco.h"
#include "stm32f4_discovery.h"
//#include "tm_stm32f4_delay.h"
//#include "tm_stm32f4_usart.h"

/* Include fatfs and usb libraries */
#include "tm_stm32f4_fatfs.h"
#include "tm_stm32f4_usb_msc_host.h"
#include "command.h"
#include "flash_if.h"
#include "timer.h"

#include "tm_stm32f4_usb_vcp.h"

#include <stdio.h>

#define SIGNAL_WORD_RAM_ADDR  ((U32*)0x2001FFFC) // this last byte of RAM is kept outside of the stack to hold intact
#define SIGNAL_JUMP_TO_APP    ((U32)0xDEADBEEF)

//#define TM_DISCO_LedInit STM_EVAL_LEDInit
#define TM_DISCO_LedOn STM_EVAL_LEDOn
#define TM_DISCO_LedOff STM_EVAL_LEDOff

pFunction Jump_To_Application;
uint32_t JumpAddress;

void TM_DISCO_LedInit()
{
   STM_EVAL_LEDInit(LED_GREEN);
   STM_EVAL_LEDInit(LED_RED);
   STM_EVAL_LEDInit(LED_ORANGE);
   STM_EVAL_LEDInit(LED_BLUE);
}

void Signal_FlashReady()
{
   U32 *ptr = SIGNAL_WORD_RAM_ADDR;
   *ptr = SIGNAL_JUMP_TO_APP;
}

U8 Check_FlashReady()
{
   U32 *ptr = SIGNAL_WORD_RAM_ADDR;
   if ((*(__IO uint32_t*)APPLICATION_ADDRESS) == (U32)0x20020000)
   {
      if (*ptr == SIGNAL_JUMP_TO_APP)
      {
         *ptr = (U32)0;
         return 1;
      }
   }
   return 0;
}

void DeviceMode()
{
   uint8_t c;

   TM_USB_MSCHOST_DeInit();

   /* Initialize USB VCP */
   TM_USB_VCP_Init();

   STM_EVAL_LEDOff(LED_BLUE);
   STM_EVAL_LEDOff(LED_ORANGE);

   while (1)
   {
      /* USB configured OK, drivers OK */
      if (TM_USB_VCP_GetStatus() == TM_USB_VCP_CONNECTED)
      {
         /* Turn on GREEN led */
         STM_EVAL_LEDOff(LED_RED);
         STM_EVAL_LEDOn(LED_GREEN);

         /* If something arrived at VCP */
         if (TM_USB_VCP_Getc(&c) == TM_USB_VCP_DATA_OK)
         {
            /* Return data back */
            TM_USB_VCP_Putc(c + 1);
         }
      }
      else
      {
         /* USB not OK */
         STM_EVAL_LEDOn(LED_RED);
         STM_EVAL_LEDOff(LED_GREEN);
      }
   }
}

int main(void) {
   FATFS USB_Fs;
   U32 n_max_tries = 40000, n_tries = 0; // = 2s if unit is 50 us

   /* Flash unlock */
   FLASH_If_FlashUnlock();

   if (Check_FlashReady())
   {
      __disable_irq();
      /* Jump to user application */
      JumpAddress = *(__IO uint32_t*) (APPLICATION_ADDRESS + 4);
      Jump_To_Application = (pFunction) JumpAddress;
      /* Initialize user application's Stack Pointer */
      __set_MSP(*(__IO uint32_t*) APPLICATION_ADDRESS);
      Jump_To_Application();
   }

   /* Leds init */
   TM_DISCO_LedInit();

   /* Initialize delay functions */
   TimerUS_Enable();

   /* Initialize USB MSC HOST */
   TM_USB_MSCHOST_Init();

   while (1)
   {
      /* Host Task handler */
      /* This have to be called periodically as fast as possible */
      TM_USB_MSCHOST_Process();

      /* Device is connected and ready to use */
      if (TM_USB_MSCHOST_Device() == TM_USB_MSCHOST_Result_Connected)
      {
         /* Try to mount USB device */
         /* USB is at 1: */

         STM_EVAL_LEDOff(LED_BLUE);
         if (f_mount(&USB_Fs, "1:", 1) == FR_OK)
         {
            /* Mounted ok */

            COMMAND_DOWNLOAD();

            /* Unmount USB */
            f_mount(0, "1:", 1);

            COMMAND_JUMP();
         }

         /* Unmount USB */
         f_mount(0, "1:", 1);
      }
      else
      {
         STM_EVAL_LEDOn(LED_BLUE);

         /* Check Vector Table: Test if user code is programmed starting from address
          "APPLICATION_ADDRESS" */
         if (n_tries++ < n_max_tries)
            TimerUS_StartDelayAndWait(50);
         else
         {
            STM_EVAL_LEDOff(LED_BLUE);
            if (!COMMAND_JUMP())
            {
               DeviceMode();
            }

         }
      }
   }
}
