/*
 * timer.c
 *
 *  Created on: Dec 31, 2012
 *      Author: davhak
 */

#include "timer.h"

#include "system_stm32f4xx.h"
#include "stm32f4xx_tim.h"
#include "misc.h"

#include "stm32f4xx_gpio.h"


static __IO U32 g_us_delay = 0;
static       U8 g_is_us_timer_on = 0;

void TIM2_IRQHandler(void)
{
	if (RESET != TIM_GetITStatus(TIMER_TIM, TIM_IT_Update))
	{
		TIM_ClearITPendingBit(TIMER_TIM, TIM_IT_Update );

      if (g_us_delay)
         --g_us_delay;
		if (!g_us_delay)
		{
			TIMER_TIM->CR1 &= (uint16_t)~TIM_CR1_CEN;
//			TIMER_TIM->DIER &= (uint16_t)~TIM_IT_Update;
		}
	}
}

void TimerUS_Enable()
{
	NVIC_PriorityGroupConfig( NVIC_PriorityGroup_1 );
	RCC_APB1PeriphClockCmd(RCC_1US_TIMER, ENABLE);

	/* Configuration 1 us */
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
	TIM_TimeBaseStructure.TIM_Period = 84 - 1 ; // since APB1 prescaler is 4 (not 1) so Timer clock is x2 of APB1 i.e. 84MHz, see datasheet
	TIM_TimeBaseStructure.TIM_Prescaler = 1 - 1; // no divider
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIMER_TIM, &TIM_TimeBaseStructure);

	/* Enable and configure TIMER_TIM IRQ channel */
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	TIM_ITConfig(TIMER_TIM, TIM_IT_Update, ENABLE);
	TIM_Cmd(TIMER_TIM, DISABLE);
	g_is_us_timer_on = 1;
}

void TimerUS_Disable()
{
	g_is_us_timer_on = 0;
	TIM_ITConfig(TIMER_TIM, TIM_IT_Update, DISABLE);
   TIM_Cmd(TIMER_TIM, DISABLE);
}

U8 IsTimerUS_Enabled()
{
   return g_is_us_timer_on;
}

void TimerUS_StartDelayAndReturn(U32 delay)
{
   if (!delay) return;

//   if (!g_is_us_timer_on)
//      TimerUS_Enable();

	g_us_delay = delay;
   TIMER_TIM->CR1 |= TIM_CR1_CEN;
}

void TimerUS_StartDelayAndWait(U32 delay)
{
   if (!delay) return;

   // see later comments
	g_us_delay = delay - 1;

   if (g_us_delay)
   {
      TIMER_TIM->CR1 |= TIM_CR1_CEN;
      while(g_us_delay);
   }
   else
   {
      // see below comments
      for (; g_us_delay < 3; ++g_us_delay);
   }


   // g_us_delay < 10 found empirically (together with the above < 3).
   // This way the delays caused by the entrance and exit of TimerUS_StartDelayAndWait is mostly
   // taken into account. Of course this is true only at 168MHz core clock
   // and for the optimization level mentioned in the current release build options.
   for (g_us_delay = 0; g_us_delay < 10; ++g_us_delay);
   g_us_delay = 0;
}

U8 TimerUS_IsBusy()
{
	return (g_is_us_timer_on !=0 && g_us_delay != 0);
}
