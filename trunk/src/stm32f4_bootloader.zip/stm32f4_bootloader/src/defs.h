/*
 * defs.h
 *
 *  Created on: Nov 24, 2012
 *      Author: davhak
 */

#ifndef MISC_DEFS_H_
#define MISC_DEFS_H_

#include <stdint.h>
#include "stm32f4xx.h"

#ifndef NULL
#define NULL    0
#endif

#define __I    volatile const   /*!< defines 'read only' permissions      */
#define __O    volatile         /*!< defines 'write only' permissions     */
#define __IO   volatile         /*!< defines 'read / write' permissions   */

#define set_bits(reg, bit)	SET_BIT(reg, bit)
#define tst_bits(reg, bit)	READ_BIT(reg, bit)
#define clr_bits(reg, bit)	CLEAR_BIT(reg, bit)

typedef uint8_t	U8;
typedef uint16_t	U16;
typedef uint32_t	U32;
typedef uint64_t  U64;
typedef int8_t    S8;
typedef int16_t	S16;
typedef int32_t	S32;

/* The following is valid for discovery board only */
#define LED_GREEN_PIN                    GPIO_Pin_12
#define LED_GREEN_GPIO_PORT              GPIOD
#define LED_GREEN_GPIO_CLK               RCC_AHB1Periph_GPIOD

#define LED_ORANGE_PIN                   GPIO_Pin_13
#define LED_ORANGE_GPIO_PORT             GPIOD
#define LED_ORANGE_GPIO_CLK              RCC_AHB1Periph_GPIOD

#define LED_RED_PIN                      GPIO_Pin_14
#define LED_RED_GPIO_PORT                GPIOD
#define LED_RED_GPIO_CLK                 RCC_AHB1Periph_GPIOD

#define LED_BLUE_PIN                     GPIO_Pin_15
#define LED_BLUE_GPIO_PORT               GPIOD
#define LED_BLUE_GPIO_CLK                RCC_AHB1Periph_GPIOD

#define TOUP(x)                          ((x >= 'a' && x <= 'z') ? (x - 'a' + 'A') : x)
#define STRLEN(x)                        (sizeof(x)-1)

#define GENERIC_RESP_OK                  "OK\r>"
#define GENERIC_RESP_READY               "\r>"

void Hex2Ascii(U8 c, char* p);
void ultoa10(U32 number, char* number_string);

#endif /* MISC_DEFS_H_ */
