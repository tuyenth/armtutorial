/**
  ******************************************************************************
  * @file    FW_upgrade/src/command.c
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    28-October-2011
  * @brief   This file provides all the IAP command functions.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "command.h"
#include "flash_if.h"
#include "timer.h"

#include "defines.h"
#include "tm_stm32f4_fatfs.h"
#include "tm_stm32f4_usb_msc_host.h"
//#include "tm_stm32f4_delay.h"
#include "stm32f4_discovery.h"

#include <string.h>
//#include <math.h>

/** @addtogroup STM32F4-Discovery_FW_Upgrade
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private defines -----------------------------------------------------------*/
#define UPLOAD_FILENAME            "0:UPLOAD.BIN"
#define DOWNLOAD_FILENAME_USB      "1:app.bin"

/* Private macros ------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/

/* This value can be equal to (512 * x) according to RAM size availability with x=[1, 128]
   In this project x is fixed to 64 => 512 * 64 = 32768bytes = 32 Kbytes */
#define BUFFER_SIZE        ((uint16_t)512*1)

static FIL fileR;

/**
  * @brief  This function handles the program fail.
  * @param  None
  * @retval None
  */
void Fail_Handler(void)
{
   /* Set Blue LED ON */
   STM_EVAL_LEDOff(LED_BLUE);
   STM_EVAL_LEDOff(LED_RED);
   STM_EVAL_LEDOff(LED_ORANGE);
   STM_EVAL_LEDOff(LED_GREEN);
   while(1)
   {
      /* Toggle Red LED */
      STM_EVAL_LEDToggle(LED_RED);
      TimerUS_StartDelayAndWait(200 * 1000);
   }
}


/**
  * @brief  IAP write memory
  * @param  None
  * @retval None
  */
void COMMAND_DOWNLOAD(void)
{
   /* Open the binary file to be downloaded */
   if (f_open(&fileR, DOWNLOAD_FILENAME_USB, FA_READ) == FR_OK)
   {
      if (fileR.fsize > USER_FLASH_SIZE)
      {
         /* Toggle Red LED in infinite loop: No available Flash memory size for
            the binary file */
         Fail_Handler();
      }
      else
      {
         /* Download On Going: Set Blue LED ON */
         STM_EVAL_LEDOn(LED_GREEN);

         /* Erase FLASH sectors to download image */
         if (FLASH_If_EraseSectors(APPLICATION_ADDRESS) != 0x00)
         {
            Fail_Handler();
         }

         STM_EVAL_LEDOn(LED_ORANGE);
         /* Program flash memory */
         COMMAND_ProgramFlashMemory();
         STM_EVAL_LEDOff(LED_ORANGE);

         /* Close file and filesystem */
         f_close (&fileR);

         STM_EVAL_LEDOff(LED_GREEN);
      }
   }

   else
   {
      // Toggle Red LED in infinite loop: the binary file is not available
      // Fail_Handler();
      STM_EVAL_LEDOff(LED_BLUE);
      STM_EVAL_LEDOff(LED_RED);
      STM_EVAL_LEDOn(LED_ORANGE);
      STM_EVAL_LEDOff(LED_GREEN);
   }
}

/**
  * @brief  IAP jump to user program
  * @param  None
  * @retval None
  */
uint8_t COMMAND_JUMP(void)
{
   if ((*(__IO uint32_t*)APPLICATION_ADDRESS) == 0x20020000)
   {
      Signal_FlashReady();

      NVIC_SystemReset();
      return 1;
   }
   return 0;
}

/**
  * @brief  Programs the internal Flash memory
  * @param  None
  * @retval None
  */
void COMMAND_ProgramFlashMemory(void)
{
   static uint8_t RAM_Buf[BUFFER_SIZE] = { 0x00 };
   static uint32_t TmpProgramCounter = 0x00, TmpReadSize = 0x00 , RamAddress = (uint32_t) & RAM_Buf;
   uint32_t LastPGAddress = APPLICATION_ADDRESS;

   __IO uint32_t programcounter = 0x00;
   uint8_t readflag = TRUE;
   uint16_t BytesRead;

   /* While file still contain data */
   while ((readflag == TRUE) && TM_USB_MSCHOST_Device() == TM_USB_MSCHOST_Result_Connected)
   {
      //TM_USB_MSCHOST_Process();

      /* Read maximum BUFFER_SIZE byte from the selected file */
      f_read (&fileR, RAM_Buf, BUFFER_SIZE, (void *)&BytesRead);

      /* Temp variable */
      TmpReadSize = BytesRead;

      /* The read data < "BUFFER_SIZE" Kbyte */
      if (TmpReadSize < BUFFER_SIZE)
      {
         readflag = FALSE;
      }

      // Program flash memory
      for (programcounter = TmpReadSize; programcounter != 0; programcounter -= 4)
      {
         TmpProgramCounter = programcounter;
         // Write word into flash memory
         if (FLASH_If_ProgramWord((LastPGAddress - TmpProgramCounter + TmpReadSize), \
           *(__IO uint32_t *)(RamAddress - programcounter + TmpReadSize)) != FLASH_COMPLETE)
         {
            // Toggle Red LED in infinite loop: Flash programming error
            Fail_Handler();
         }
      }

      /* Update last programmed address value */
      LastPGAddress = LastPGAddress + TmpReadSize;
   }
}

/**
  * @}
  */

/*******************(C)COPYRIGHT 2011 STMicroelectronics *****END OF FILE******/
