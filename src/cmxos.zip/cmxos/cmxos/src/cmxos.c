#include "cmxos.h"

/* variables */
static uint32_t     msp_in_use = 1;
static task_table_t task_table[MAX_TASKS];
static uint32_t     current_task = 0;

/* functions */
void CMXOS_Init(void)
{
	int i;
	for (i = 0; i < MAX_TASKS; i++)
	{
		task_table[i].flags = 0;
	}
}

void CMXOS_TaskExit(void)
{

}

uint32_t CMXOS_TaskInit(task_t *task, void *entry_point)
{
   	int i;
   	hw_stack_frame_t *process_frame;

	task->stack = (void*)(((uint32_t)task->stack_start) + TASK_STACK_SIZE - sizeof(hw_stack_frame_t));

	process_frame = (hw_stack_frame_t*)(task->stack);
	process_frame->r0 = 0;
	process_frame->r1 = 0;
	process_frame->r2 = 0;
	process_frame->r3 = 0;
	process_frame->r12 = 0;
	process_frame->pc = (uint32_t)entry_point;
	process_frame->lr = (uint32_t)CMXOS_TaskExit;
	process_frame->psr = 0x21000000;

	for (i = 0; i < MAX_TASKS; i++)
	{
		if (!(task_table[i].flags & IN_USE_FLAG))
		{
			task_table[i].task = task;
			task_table[i].flags = (IN_USE_FLAG | EXEC_FLAG);
			return 1;
		}
	}
	return 0;
}


void __attribute__((naked)) SysTick_Handler(void)
{

	if (!msp_in_use)
	{
		__asm volatile
		(
			"STMIA %1!, {R4-R11} \n\t"
			"MRS   %0,  PSP      \n\t"
			: "=r" (task_table[current_task].task->stack)
			: "r" (&task_table[current_task].task->sw_stack_frame)
		);

        current_task = (current_task + 1) % MAX_TASKS;

	}
	else
    {
        msp_in_use = 0;
    }

	__asm volatile(
		"MOV   LR,  #0xFFFFFFFD \n\t"
		"LDMIA %0!, {R4-R11}    \n\t"
		"MSR   PSP, %1          \n\t"
		"BX    LR                   "
		: : "r" (&task_table[current_task].task->sw_stack_frame),
		    "r" (task_table[current_task].task->stack)
	);

}

