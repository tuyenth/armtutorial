#ifndef RC5_DECODE_H_INCLUDED
#define RC5_DECODE_H_INCLUDED

#define Start_Timer()  (TIM_SetCounter(TIM2,0),TIM_Cmd(TIM2,ENABLE))
#define Stop_Timer()   TIM_Cmd(TIM2,DISABLE)

void Configure_PA0(void);
void Configure_TIM2(void);

#endif /* RC5_DECODE_H_INCLUDED */
