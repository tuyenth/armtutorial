#include <stdio.h>
#include "stm32f4xx.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "nec_endcode.h"

#define SET_IROUT() GPIO_SetBits(GPIOB,GPIO_Pin_3)
#define CLR_IROUT() GPIO_ResetBits(GPIOB,GPIO_Pin_3)

const uint32_t ReloadTB[2][2] =
{
    { 562-1, 562-1   },  // bit 0
    { 562-1, 1687-1  }   // bit 1
};

static uint32_t bit_pos;
static uint32_t bit_val;
static uint32_t frame;
static uint32_t space;
static uint32_t sending;
static uint32_t start_frame;
static uint32_t end_frame;

/* Configure IR output pin on PB3 */
static void ConfigureGPIO(void)
{
    //Initialize struct
    GPIO_InitTypeDef GPIO_InitDef;

    //Enable clock for GPIOB
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

    //Pins 13 and 14
    GPIO_InitDef.GPIO_Pin = GPIO_Pin_3;
    //Mode output
    GPIO_InitDef.GPIO_Mode = GPIO_Mode_OUT;
    //Output type push-pull
    GPIO_InitDef.GPIO_OType = GPIO_OType_PP;
    //Without pull resistors
    GPIO_InitDef.GPIO_PuPd = GPIO_PuPd_NOPULL;
    //50MHz pin speed
    GPIO_InitDef.GPIO_Speed = GPIO_Speed_50MHz;

    //Initialize pins on GPIOG port
    GPIO_Init(GPIOB, &GPIO_InitDef);
}

/* Configure TIM2 */
static void ConfigureTimer2(void)
{
    NVIC_InitTypeDef NVIC_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

    /* Enable the TIM2 global Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    /* TIM2 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    /* Time base configuration, input clock = 84MHz */
    TIM_TimeBaseStructure.TIM_Period = 9000 - 1;  // 9 ms
    TIM_TimeBaseStructure.TIM_Prescaler = 84 - 1; // TIM2 clock input = 84MHz => 1MHz period
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    /* TIM2 disable counter */
    TIM_Cmd(TIM2, DISABLE);

    /* Reset counter */
    TIM_SetCounter(TIM2, 0);

    /* TIM IT enable */
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
}

static void CreateFrame(uint8_t addr, uint8_t cmd)
{
   uint8_t addr_i = ~addr;
   uint8_t cmd_i  = ~cmd;

   /* calculate frame data */
   frame = ((uint32_t)(addr) |
            (uint32_t)(addr_i << 8) |
            (uint32_t)(cmd << 16) |
            (uint32_t)(cmd_i << 24));
}

void NECIR_EndCoderInit(void)
{
    ConfigureGPIO();
    CLR_IROUT();
    ConfigureTimer2();
    sending = 0;
}

void NECIR_SendFrame(uint8_t addr, uint8_t cmd)
{
    if (sending == 0)
    {
        /* Create frame */
        CreateFrame(addr, cmd);

        /* Initialize global variables */
        bit_pos = 0;
        space = 0;
        sending = 1;
        start_frame = 1;
        end_frame = 0;

        /* Start frame burst width setting */
        TIM_SetAutoreload(TIM2, 9000-1);

        /* Start frame burst level output */
        SET_IROUT();

        /* Start Timer */
        TIM_Cmd(TIM2, ENABLE);
    }
    else
    {
        /* do nothing */
    }
}

uint32_t NECIR_IsSending(void)
{
    return sending;
}

/* TIM2 IRQ Handler */
void TIM2_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        if(start_frame == 1)
        {
           /* Start frame space level output */
           CLR_IROUT();
           TIM_SetAutoreload(TIM2, 4500-1);
           start_frame = 0;
        }
        else if (bit_pos <= 31)
        {
            bit_val = (frame & (1 << bit_pos)) ? 1 : 0;

            if(space == 0) // send burst
            {
                SET_IROUT();
                TIM_SetAutoreload(TIM2, ReloadTB[bit_val][space]);
                space = 1;
            }
            else // send space
            {
                CLR_IROUT();
                TIM_SetAutoreload(TIM2, ReloadTB[bit_val][space]);
                space = 0;
                bit_pos++; // Increase bit position
            }

        }
        else  // frame has been sent
        {
            if(end_frame == 0)
            {
                /* burst level of end frame */
                SET_IROUT();
                TIM_SetAutoreload(TIM2, 562-1);
                end_frame = 1;
            }
            else
            {
                /* TIM2 disable counter */
                TIM_Cmd(TIM2, DISABLE);
                /* Reset counter */
                TIM_SetCounter(TIM2, 0);
                /* Notify done */
                sending = 0;
                /* IROUT = 0 */
                CLR_IROUT();
            }
        }

        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    }
}
