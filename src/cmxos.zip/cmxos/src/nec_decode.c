#include <stdio.h>
#include <string.h>
#include "stm32f4xx.h"
#include "stm32f4xx_exti.h"
#include "stm32f4xx_syscfg.h"
#include "misc.h"
#include "nec_decode.h"

#define Start_Timer()  (TIM_SetCounter(TIM5,0),TIM_Cmd(TIM5,ENABLE))
#define Stop_Timer()   TIM_Cmd(TIM5,DISABLE)

/* (start bit + 32 bit data) x 2 + 1 (stop) */
static uint32_t sample[67];
static uint32_t idx;

/* Configure pin PB1 to be interrupts */
static void ConfigureInput(void)
{
    /* Set variables used */
    GPIO_InitTypeDef GPIO_InitStruct;
    EXTI_InitTypeDef EXTI_InitStruct;
    NVIC_InitTypeDef NVIC_InitStruct;

    /* Enable clock for GPIOA */
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
    /* Enable clock for SYSCFG */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

    /* Set pin as input */
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* Wait for IR line idles */
    while(!GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));

    /* Tell system that you will use PA0 for EXTI_Line0 */
    SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource0);

    /* PB1 is connected to EXTI_Line1 */
    EXTI_InitStruct.EXTI_Line = EXTI_Line0;
    /* Enable interrupt */
    EXTI_InitStruct.EXTI_LineCmd = ENABLE;
    /* Interrupt mode */
    EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
    /* Triggers on rising and falling edge */
    EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
    /* Add to EXTI */
    EXTI_Init(&EXTI_InitStruct);

    /* Add IRQ vector to NVIC */
    /* PA0 is connected to EXTI_Line0, which has EXTI0_IRQn vector */
    NVIC_InitStruct.NVIC_IRQChannel = EXTI0_IRQn;
    /* Set priority */
    NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0x00;
    /* Set sub priority */
    NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0x00;
    /* Enable interrupt */
    NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
    /* Add to NVIC */
    NVIC_Init(&NVIC_InitStruct);
    /* Disable IRQ */
    NVIC_DisableIRQ(EXTI0_IRQn);
}


/* Configure TIM5 */
static void ConfigureTimer5(void)
{

    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;

    /* TIM2 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
    /* Time base configuration, input clock = 84MHz */
    TIM_TimeBaseStructure.TIM_Period = 0xFFFFFFFF;   // Set to max
    TIM_TimeBaseStructure.TIM_Prescaler = 84 - 1;    // TIM2 clock input = 84MHz => 1MHz period
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

    /* TIM2 disable counter */
    TIM_Cmd(TIM5, DISABLE);

    /* Reset counter */
    TIM_SetCounter(TIM5, 0);
}

void NECIR_DeCoderInit(void)
{
    ConfigureInput();
    ConfigureTimer5();
}

uint32_t NECIR_ReceiveFrame(void)
{
    /* Initialize variables */
    memset(sample, 0, 67);
    idx = 0;

    /* Enable IRQ */
    NVIC_EnableIRQ(EXTI0_IRQn);
    return 0;
}

void EXTI0_IRQHandler(void)
{
    uint32_t i;
    /* Make sure that interrupt flag is set */
    if (EXTI_GetITStatus(EXTI_Line0) != RESET)
    {
        if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            // rising edge
            // printf("rising edge\r\n");
            Stop_Timer();

            if (idx <= 66)
            {
                /* Get Sample */
                sample[idx] = TIM_GetCounter(TIM5);
                idx++;
            }
            else
            {
                printf("\r\nIndex = %d\r\n", idx);
                for (i = 0; i <= 65; i++)
                {
                    printf("%4d ", sample[i]);
                    if((i%2) != 0)
                    {
                        printf("\r\n");
                    }
                }
                idx = 0;
            }

        }
        else
        {
            // falling edge
            Start_Timer();
        }

        EXTI_ClearITPendingBit(EXTI_Line0);
    }
}
