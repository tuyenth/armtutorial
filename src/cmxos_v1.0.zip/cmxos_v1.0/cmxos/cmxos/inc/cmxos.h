#ifndef __CMXOS_H__
#define __CMXOS_H__

#include "stm32f4xx_conf.h"

#define IN_USE_FLAG			0x00000001
#define EXEC_FLAG			0x00000002

#define MAX_TASKS 			4
#define TASK_STACK_SIZE 	1024

typedef struct
{
    /* sw stack frame */
  	uint32_t r4;
	uint32_t r5;
	uint32_t r6;
	uint32_t r7;
	uint32_t r8;
	uint32_t r9;
	uint32_t r10;
	uint32_t r11;

    /* hardware stack frame */
	uint32_t r0;
	uint32_t r1;
	uint32_t r2;
	uint32_t r3;
	uint32_t r12;
	uint32_t lr;
	uint32_t pc;
	uint32_t psr;

} stack_frame_t;



typedef struct
{
	uint8_t stack_start[TASK_STACK_SIZE];
	void *stack;
} task_t;

typedef struct
{
	task_t *task;
	uint32_t flags;
} task_table_t;


void CMXOS_Init(void);
uint32_t CMXOS_TaskInit(task_t *task, void *entry_point);

#endif // __CMXOS_H__
