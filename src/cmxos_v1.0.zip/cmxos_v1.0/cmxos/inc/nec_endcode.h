#ifndef NEC_ENDCODE_H_INCLUDED
#define NEC_ENDCODE_H_INCLUDED

void NECIR_EndCoderInit(void);
void NECIR_SendFrame(uint8_t addr, uint8_t cmd);
uint32_t NECIR_IsSending(void);

#endif
