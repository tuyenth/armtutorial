#ifndef UART_H_INCLUDED
#define UART_H_INCLUDED

void uart_init(void);
int SendChar(int ch);

#endif /* UART_H_INCLUDED */
