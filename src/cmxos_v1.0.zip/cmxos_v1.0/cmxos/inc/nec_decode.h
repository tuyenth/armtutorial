#ifndef NEC_DECODE_H_INCLUDED
#define NEC_DECODE_H_INCLUDED

void NECIR_DeCoderInit(void);
uint32_t NECIR_ReceiveFrame(void);

#endif /* NEC_DECODE_H_INCLUDED */
