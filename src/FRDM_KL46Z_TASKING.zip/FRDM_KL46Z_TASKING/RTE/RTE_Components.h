
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'rtos' 
 * Target:  'KL46Z256' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define RTE_DEVICE_STARTUP_KLxx    /* Device Startup for KLxx */

#endif /* RTE_COMPONENTS_H */
