#include "MKL46Z4.h"

#define RED_LED_PIN     (1<<29)
#define GREEN_LED_PIN   (1<<5)

#define IN_USE_FLAG			0x00000001
#define EXEC_FLAG			  0x00000002

#define MAX_TASKS 			2
#define TASK_STACK_SIZE 1024

typedef struct
{
  /* sw stack frame */
  uint32_t r4;
	uint32_t r5;
	uint32_t r6;
	uint32_t r7;
	uint32_t r8;
	uint32_t r9;
	uint32_t r10;
	uint32_t r11;

    /* hardware stack frame */
	uint32_t r0;
	uint32_t r1;
	uint32_t r2;
	uint32_t r3;
	uint32_t r12;
	uint32_t lr;
	uint32_t pc;
	uint32_t psr;

} stack_frame_t;

typedef struct
{
	uint8_t stack_start[TASK_STACK_SIZE];
	void *stack;
} task_t;

typedef struct
{
	task_t *task;
	uint32_t flags;
} task_table_t;

/* variables */
volatile uint32_t   msp_in_use = 1;
static task_table_t task_table[MAX_TASKS];
static uint32_t     current_task = 0;
volatile uint32_t   p_stack;

/* functions */
void CMXOS_Init(void)
{
	int i;
	for (i = 0; i < MAX_TASKS; i++)
	{
		task_table[i].flags = 0;
	}
}

void CMXOS_TaskExit(void)
{

}

uint32_t CMXOS_TaskInit(task_t *task, void *entry_point)
{
   	int i;
   	stack_frame_t *process_frame;

	task->stack = (void*)(((uint32_t)task->stack_start) + TASK_STACK_SIZE - sizeof(stack_frame_t));
	process_frame = (stack_frame_t*)(task->stack);
	process_frame->r0 = 0;
	process_frame->r1 = 0;
	process_frame->r2 = 0;
	process_frame->r3 = 0;
	process_frame->r12 = 0;
	process_frame->pc = (uint32_t)entry_point;
	process_frame->lr = (uint32_t)CMXOS_TaskExit;
	process_frame->psr = 0x21000000;

	process_frame->r4  = 0x4;
	process_frame->r5  = 0x5;
	process_frame->r6  = 0x6;
	process_frame->r7  = 0x7;
	process_frame->r8  = 0x8;
	process_frame->r9  = 0x9;
	process_frame->r10 = 0x10;
	process_frame->r11 = 0x11;
	
	for (i = 0; i < MAX_TASKS; i++)
	{
		if (!(task_table[i].flags & IN_USE_FLAG))
		{
			task_table[i].task = task;
			task_table[i].flags = (IN_USE_FLAG | EXEC_FLAG);
			return 1;
		}
	}
	return 0;
}

void save_context(void)
{
	task_table[current_task].task->stack = (void *) p_stack;
}

void switch_context(void)
{
	current_task = (current_task + 1) % MAX_TASKS;
}

void load_context(void)
{
	p_stack = (uint32_t)task_table[current_task].task->stack;
}

task_t task_01;
task_t task_02;

void task_01_func(void)
{
    while (1)
    {
       FPTE->PSOR |= RED_LED_PIN;
			 FPTD->PCOR |= GREEN_LED_PIN; 
    }
}

void task_02_func(void)
{
    while (1)
    {
			 FPTD->PSOR |= GREEN_LED_PIN;
       FPTE->PCOR |= RED_LED_PIN;
    }
}

void init_led()
{
    /* Enable clock for PORTE & PORTD*/
    SIM->SCGC5 |= ( SIM_SCGC5_PORTD_MASK
                    | SIM_SCGC5_PORTE_MASK );
    /* 
    * Initialize the RED LED (PTE5)
    */
    PORTE->PCR[29] = PORT_PCR_MUX(1);

    /* Set the pins direction to output */
    FPTE->PDDR |= RED_LED_PIN;

    /* Set the initial output state to high */
    FPTE->PSOR |= RED_LED_PIN;

    /* 
    * Initialize the Green LED (PTE5)
    */

    /* Set the PTE29 pin multiplexer to GPIO mode */
    PORTD->PCR[5]= PORT_PCR_MUX(1);

    /* Set the pins direction to output */
    FPTD->PDDR |= GREEN_LED_PIN;

    /* Set the initial output state to high */
    FPTD->PSOR |= GREEN_LED_PIN;
}

int main (void)
{
  SystemCoreClockUpdate();
	
	init_led();
	
  CMXOS_Init();
  CMXOS_TaskInit(&task_01, task_01_func);
  CMXOS_TaskInit(&task_02, task_02_func);	
	
  SysTick_Config(SystemCoreClock/5);	
	
	while(1)
	{
	}
}


